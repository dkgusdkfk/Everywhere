CREATE DATABASE  IF NOT EXISTS `everywhere` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `everywhere`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: everywhere
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT,
  `admin_id` varchar(45) NOT NULL,
  `title` varchar(145) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `hit` int DEFAULT '0',
  `register_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (3,'admin','공지사항 테스트','테스트',0,'2023-05-26 01:24:28'),(4,'admin','허위 광고 금지입니다','허위 광고 금지합니다',0,'2023-05-26 01:25:11'),(5,'admin','[ 안내 ] 코로나19 관련 국가별 확진자 현황',' 각국의 확진자 현황 관련 보건복지부 홈페이지 링크를 아래와 같이 첨부하오니 참고하시기 바랍니다. \n\n※ 보건복지부 홈페이지(링크)',1,'2023-05-26 01:26:54'),(6,'admin','[ 안내 ] 코로나19 관련 각국의 해외입국자에 대한 입국제한 조치 실시 국가(지역) (5.25.17:00)','★ 붙임의 조치 현황은 국민들의 편의를 위하여 정보 제공 차원에서 참고로 작성된 것임을 알려드립니다. 보다 상세한 정보 확인을 위해서는 방문하시려는 국가/지역 정부의 공식 홈페이지 또는 해당 지역 관할 우리 재외공관 홈페이지 등을 필수적으로 참고하시기 바랍니다. ★ \n\n\n\n○ 코로나19와 관련하여 해외입국자에 대한 입국제한 조치를 실시하고 있는 국가(지역)를 붙임과 같이 안내합니다.\n\n\n\n○ 2022.7.1부터 유럽연합과의 코로나 19 증명서 상호인정 합의에 따라 COOV 앱 증명서는 유럽연합 27개 회원국과 노르웨이, 리히텐슈타인, 스위스, 아이슬란드 등 총 31개국에서 유럽연합 디지털코로나증명서(EU DCC)와 동등하게 취급 \n\n\n\n※ 입국이 허용되는 조건을 갖추더라도 각국의 입국(국경)을 관리하는 실무자의 판단에 따라 입국이 거절되는 경우가 생길 수 있습니다.\n\n\n\n※ 붙임: 코로나 19 확산 관련 각국의 해외입국자에 대한 조치 현황(5월 25일 17:00 현재) ',0,'2023-05-26 01:28:47'),(7,'admin','출국 전 해외여행자보험 가입 안내','□ 해외 체류 중 현지 치료‧입원 또는 국내이송이 필요한 상황에 대비하여, 출국 전 해외여행자보험 또는 장기체류보험(이하 해외여행자보험으로 통칭)에 가입하실 것을 권장드립니다.\n\n- 해외여행자보험: 해외여행 중 발생할 수 있는 다양한 손해를 보장해주는 손해보험상품\n\n\n\n\n\n□ 특히, 금융감독원은 해외 환자의 원활한 국내이송을 위해 손해보험협회 등과 협의를 통하여 중대사고 구조송환비용특약*을 개선하였으며, 현재 일부 손해보험사는 인터넷을 통해 특약 개선 상품을 출시하였습니다.\n\n\n\n* 구조송환비용특약: 해외여행중 피보험자가 조난, 행방불명, 상해·질병으로 사망 또는 일정기간 이상 계속 입원시 국내이송비용, 수색구조비용, 교통비, 숙박비 등을 실손 보상하는 선택계약\n\n\n\n- (계속입원요건 다양화) 현지 최소입원요건 14일 → 4일/7일/14일\n- (보장한도 상향) 50만원~5천만원 → 1백만원~1억원\n\n\n\n\n\n□ 해외여행자보험은 손해보험회사 홈페이지, 대리점, 공항 내 보험회사 창구 등을 통해 가입이 가능합니다.\n\n\n\n- 『보험다모아』(https://e-insmarket.or.kr)를 통해 보험회사별 해외여행보험 보험료 비교 및 보험가입 가능*\n\n* ① ｢보험다모아」 접속 → ② 보험상품 알아보기 중 ’여행자보험‘ 선택 → ③ ’보험상품 비교하기’에서 보험료 등 비교→ ④ ‘인터넷 바로가입’ 클릭\n\n\n\n\n\n□ 해외여행자보험 상품 가입 관련 자세한 사항은 각 손해보험사에 문의(붙임파일 대표전화번호 참고)하시기 바랍니다.\n\n',1,'2023-05-26 01:29:43'),(8,'admin','시스템 점검에 따른 홈페이지, 앱 접속 일시 제한 안내','외교부 해외안전여행 홈페이지, 앱을 이용해주셔서 감사합니다.\n\n\n\n해외안전여행 홈페이지, 앱을 안정적 서비스 제공을 위해 아래 시간동안 접속이 제한되오니 이용에 참고하시기 바랍니다.\n\n\n\n\n\n\n\n2021.10.29.(금) 20:00 - 10.30(토) 9:00\n\n\n\n',0,'2023-05-26 01:30:18');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-26  1:44:39
